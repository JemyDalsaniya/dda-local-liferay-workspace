package dda.marketplace.portlet.service;

import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.portal.kernel.exception.PortalException;
import org.osgi.annotation.versioning.ProviderType;

import java.util.List;

@ProviderType
public interface DdaMarketplaceService {

        List<CPDefinition> getAllProductList() throws PortalException;
}
