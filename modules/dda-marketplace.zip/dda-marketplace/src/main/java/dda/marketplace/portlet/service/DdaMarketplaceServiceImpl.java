package dda.marketplace.portlet.service;

import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetTag;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetTagLocalServiceUtil;
import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.commerce.product.service.CPDefinitionLocalServiceUtil;
import com.liferay.object.model.ObjectDefinition;
import com.liferay.object.model.ObjectEntry;
import com.liferay.object.model.ObjectRelationship;
import com.liferay.object.service.ObjectDefinitionLocalServiceUtil;
import com.liferay.object.service.ObjectEntryLocalServiceUtil;
import com.liferay.object.service.ObjectRelationshipLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ServiceScope;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Component(
        service = DdaMarketplaceService.class,
        scope = ServiceScope.PROTOTYPE
)
public class DdaMarketplaceServiceImpl implements DdaMarketplaceService {

    private static final Log _log = LogFactoryUtil.getLog(DdaMarketplaceServiceImpl.class.getName());


    @Override
    public List<CPDefinition> getAllProductList() throws PortalException {
        List<CPDefinition> productList =  CPDefinitionLocalServiceUtil.getCPDefinitions(QueryUtil.ALL_POS,QueryUtil.ALL_POS);
        try {
            long productId = productList.get(2).getCPDefinitionId();
            String productImageURL = productList.get(2).getDefaultImageThumbnailSrc(productId);
            System.out.println("product image URL: " + productImageURL);
            fetchObjectEntries();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return CPDefinitionLocalServiceUtil.getCPDefinitions(-1,-1);
    }

    void fetchObjectEntries() {
        try {
            List<CPDefinition> commerceProducts = CPDefinitionLocalServiceUtil.getCPDefinitions(QueryUtil.ALL_POS, QueryUtil.ALL_POS);
            List<ObjectRelationship> objectRelationships = ObjectRelationshipLocalServiceUtil.getObjectRelationships(QueryUtil.ALL_POS, QueryUtil.ALL_POS);


            for (CPDefinition product : commerceProducts) {
                System.out.println("\nProduct Name: " + product.getName());
                for (ObjectRelationship relationship : objectRelationships) {
                    ObjectDefinition relatedObjectDefinition = ObjectDefinitionLocalServiceUtil.getObjectDefinition(relationship.getObjectDefinitionId2());
                    if (!relatedObjectDefinition.isSystem()) {
                        long groupId = product.getGroupId();
                        long objectRelationshipId = relationship.getObjectRelationshipId();
                        long cpDefinitionId = product.getCPDefinitionId();

                        System.out.println("Fetching entries for relationship: " + relationship.getName());
                        List<ObjectEntry> entries = ObjectEntryLocalServiceUtil.getOneToManyObjectEntries(
                                groupId,
                                objectRelationshipId,
                                cpDefinitionId,
                                true,
                                "",
                                QueryUtil.ALL_POS,
                                QueryUtil.ALL_POS
                        );

                        if (entries.isEmpty()) {
                            System.out.println("No entries found for " + relatedObjectDefinition.getName());
                        } else {
                            System.out.println("Entries for " + relatedObjectDefinition.getName() + ":");
                            for (ObjectEntry entry : entries) {
                                System.out.println("Entry ID: " + entry.getObjectEntryId());
                                Map<String, Serializable> values = entry.getValues();
                                for (Map.Entry<String, Serializable> field : values.entrySet()) {
                                    System.out.println(field.getKey() + ": " + field.getValue());
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
