package dda.marketplace.util;

import com.liferay.account.model.AccountEntry;
import com.liferay.account.service.AccountEntryLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetVocabulary;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetVocabularyLocalServiceUtil;
import com.liferay.commerce.price.list.model.CommercePriceEntry;
import com.liferay.commerce.price.list.service.CommercePriceEntryLocalServiceUtil;
import com.liferay.commerce.product.model.CPAttachmentFileEntry;
import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.commerce.product.model.CPInstance;
import com.liferay.commerce.product.service.CPInstanceLocalServiceUtil;
import com.liferay.object.model.ObjectEntry;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.Validator;
import dda.marketplace.service.DdaMarketplaceService;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

import javax.portlet.RenderRequest;
import java.math.BigDecimal;
import java.util.*;

import static dda.marketplace.constants.DdaMarketplacePortletKeys.PRICE_LIST_TYPE;

@Component(
        service = DdaMarketplaceUtil.class,
        scope = ServiceScope.PROTOTYPE
)
public class DdaMarketplaceUtil {

    @Reference
    DdaMarketplaceService ddaMarketplaceService;

    private static final Log _log = LogFactoryUtil.getLog(DdaMarketplaceUtil.class);


    /**
     * Retrieves the product categories for a given CPDefinition ID, organized by vocabulary.
     *
     * @param cpDefinitionId the ID of the CPDefinition for which the categories are to be retrieved
     * @return a map where the keys are vocabulary names and the values are lists of category names
     */
    public static Map<String, List<String>> getProductCategories(long cpDefinitionId) {
        Map<String, List<String>> categoriesByVocabulary = new HashMap<>();

        try {
            List<AssetCategory> categories = AssetCategoryLocalServiceUtil.getCategories(
                    CPDefinition.class.getName(), cpDefinitionId);

            for (AssetCategory category : categories) {
                AssetVocabulary vocabulary = AssetVocabularyLocalServiceUtil.getAssetVocabulary(category.getVocabularyId());
                String vocabularyName = vocabulary.getName();

                categoriesByVocabulary.computeIfAbsent(vocabularyName, k -> new ArrayList<>())
                        .add(category.getName());
            }

        } catch (PortalException e) {
            e.printStackTrace();
        }

        return categoriesByVocabulary;
    }

    /**
     * Retrieves and categorizes the prices for a given product and sets the results as attributes
     * on the provided RenderRequest.
     *
     * @param product the product for which the prices are to be retrieved
     * @param renderRequest the RenderRequest object to which the prices will be set as attributes
     */
    public static void getPrices(CPDefinition product, RenderRequest renderRequest) {

        List<CPInstance> cpInstances = CPInstanceLocalServiceUtil.getCPDefinitionApprovedCPInstances(product.getCPDefinitionId());
        BigDecimal bronzeYearlyPrice = BigDecimal.ZERO;
        BigDecimal silverYearlyPrice = BigDecimal.ZERO;
        BigDecimal goldYearlyPrice = BigDecimal.ZERO;
        BigDecimal bronzeMonthlyPrice = BigDecimal.ZERO;
        BigDecimal silverMonthlyPrice = BigDecimal.ZERO;
        BigDecimal goldMonthlyPrice = BigDecimal.ZERO;

        if (!cpInstances.isEmpty()) {
            for (CPInstance cpInstance : cpInstances) {
                String cpInstanceUuid = cpInstance.getCPInstanceUuid();
                CommercePriceEntry commercePriceEntry = CommercePriceEntryLocalServiceUtil.getInstanceBaseCommercePriceEntry(cpInstanceUuid, PRICE_LIST_TYPE, null);

                BigDecimal price = (commercePriceEntry != null) ? commercePriceEntry.getPrice() : BigDecimal.ZERO;

                // Categorize prices
                String category = cpInstance.getSku(); // Assuming there is a method to get the category
                category = category.trim().toLowerCase().replace(" ", "");
                switch (category) {
                    case "bronze-yearly":
                        bronzeYearlyPrice = price;
                        break;
                    case "silver-yearly":
                        silverYearlyPrice = price;
                        break;
                    case "gold-yearly":
                        goldYearlyPrice = price;
                        break;
                    case "bronze-monthly":
                        bronzeMonthlyPrice = price;
                        break;
                    case "silver-monthly":
                        silverMonthlyPrice = price;
                        break;
                    case "gold-monthly":
                        goldMonthlyPrice = price;
                        break;
                    default:
                        break;
                }
            }
        }

        Map<String, BigDecimal> priceMap = new HashMap<>();
        priceMap.put("bronzeYearlyPrice", bronzeYearlyPrice);
        priceMap.put("silverYearlyPrice", silverYearlyPrice);
        priceMap.put("goldYearlyPrice", goldYearlyPrice);
        priceMap.put("bronzeMonthlyPrice", bronzeMonthlyPrice);
        priceMap.put("silverMonthlyPrice", silverMonthlyPrice);
        priceMap.put("goldMonthlyPrice", goldMonthlyPrice);

        renderRequest.setAttribute("priceMap", priceMap);
    }

    /**
     * Retrieves the current user's account ID.
     *
     * @param userId the ID of the user
     * @return the account ID of the user, or 0 if the user is a guest
     */
    public static long getCurrentUserAccountId(long userId) {
        try {
            User user = UserLocalServiceUtil.getUser(userId);

            if (!user.isGuestUser()) {
                List<AccountEntry> accountEntries = AccountEntryLocalServiceUtil.getUserAccountEntries(
                        userId, 0L, null, new String[]{"person", "business"}, -1, -1);

                if (!accountEntries.isEmpty()) {
                    long accountId = accountEntries.get(0).getAccountEntryId();

                    if (Validator.isNotNull(accountId)) {
                        return accountId;
                    }
                }
            }
        } catch (PortalException e) {
            _log.error("Error retrieving user or account entries for userId: " + userId);
        } catch (IndexOutOfBoundsException e) {
            _log.error("No account entries found for userId: " + userId);
        } catch (Exception e) {
            _log.error("Unexpected error occurred while retrieving account ID for userId: " + userId);
        }

        return -1;
    }

    /**
     * Sets various product attributes in the render request.
     *
     * @param renderRequest the render request
     * @param productId the ID of the product
     * @param userId the ID of the user
     * @param portalURL the base URL of the portal
     * @throws PortalException if an error occurs while setting the product attributes
     */
    public void setProductAttributes(RenderRequest renderRequest, long productId, long userId, String portalURL, ThemeDisplay themeDisplay) throws PortalException {
        long accountId = getCurrentUserAccountId(userId);
        CPDefinition productDetails = ddaMarketplaceService.getProductDetails(productId);
        Map<String, List<ObjectEntry>> relatedObjects = ddaMarketplaceService.getRelatedObjects(productId,renderRequest.getLocale());
        List<Map<String, Object>> fileAttachments = ddaMarketplaceService.getProductAttachments(productId, accountId, portalURL, renderRequest.getLocale(), themeDisplay);

        List<CPAttachmentFileEntry> productImage = ddaMarketplaceService.getProductImageAttachments(productId);
        boolean hasMonthlySubscription = ddaMarketplaceService.hasMonthlySubscription(productId);
        boolean hasYearlySubscription = ddaMarketplaceService.hasYearlySubscription(productId);
        Map<String, List<String>> productCategories = getProductCategories(productId);


        renderRequest.setAttribute("accountId", accountId);
        renderRequest.setAttribute("productDetails", productDetails);
        renderRequest.setAttribute("relatedObjects", relatedObjects);
        renderRequest.setAttribute("fileAttachments", fileAttachments);
        renderRequest.setAttribute("productImage", productImage);
        renderRequest.setAttribute("hasMonthlySubscription", hasMonthlySubscription);
        renderRequest.setAttribute("hasYearlySubscription", hasYearlySubscription);
        if(Validator.isNotNull(productCategories) && !productCategories.isEmpty()){
            renderRequest.setAttribute("productCategories", productCategories);
        }

    }

}
