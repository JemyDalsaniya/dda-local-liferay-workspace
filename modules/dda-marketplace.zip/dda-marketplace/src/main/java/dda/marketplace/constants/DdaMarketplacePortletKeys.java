package dda.marketplace.constants;

/**
 * @author root321
 */
public class DdaMarketplacePortletKeys {

	public static final String DDAMARKETPLACE =
		"dda_marketplace_DdaMarketplacePortlet";

	public static final String PRICE_LIST_TYPE = "price-list";

	public static final String SUBSCRIPTION_TYPE_VOCABULARY = "subscription type";

}
