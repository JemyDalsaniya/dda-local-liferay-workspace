package dda.marketplace.constants;

/**
 * @author root321
 */
public class DdaMarketplacePortletKeys {

	public static final String DDAMARKETPLACE =
		"dda_marketplace_DdaMarketplacePortlet";

}